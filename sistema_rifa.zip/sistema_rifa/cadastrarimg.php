<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imagens</title>
</head>
<body>
<form method="post">
  <label for="fk_Rifa_id">Rifa Id:</label>
  <input type="text" id="fk_Rifa_id" name="fk_Rifa_id" required>
  <br>
  <label for="link_img">Link Img:</label>
  <input type="text" id="link_img" name="link_img" required>
  <br>
  <input type="submit" value="Cadastrar">
</form>
    <?php
    require_once 'model/ImagemDAO.php';
    require_once 'model/Imagem.php';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $link_img = $_POST['link_img'];
        $fk_Rifa_id = $_POST['fk_Rifa_id'];
    
      $imagem = new Imagem(true, 0, $fk_Rifa_id, $link_img, 'CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP');
    
      var_dump($imagem);

      $imagemDAO = new ImagemDAO();
      $imagem = $imagemDAO->insert($imagem);
      if($imagem){
        var_dump($imagem);
      }
      else{
        var_dump($imagemDAO->getErro());
      }         
      
    }
    ?>
</body>
</html>